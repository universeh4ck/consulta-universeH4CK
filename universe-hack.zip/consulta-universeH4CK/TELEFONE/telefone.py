'\033[91m' "Vermelho"
'\033[92m' "Verde"
'\033[93m' "Amarelo"


print('\033[92m'





"CONSULTAS - by: universeh4ck")
print('\033[91m')
print("Consultas, cpf-telefone-gmail-nome")
print("python -t (number)")
print('\033[93mNumero da vitima: \033[93m')
